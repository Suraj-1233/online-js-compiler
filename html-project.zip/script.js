document.getElementById('btn').addEventListener('click', () => {
    document.getElementById('msg').innerText = 'You clicked the button!';
});